# <2번 제출물>
##1. Patientinfo 테이블 
###1-1.기준 attribute : age
###1-2.이유 : age(연령) attribute가 K_COVID19에 영향을 끼치는지에 대해 알아보기 위해 연령별 환자정보를 추출함

##2. Caseinfo 테이블
###2-1. 기준 attribute : infection_group
###2-2. 이유 : 감염 case가 집단감염인 경우와 집단 감염이 아닌 경우를 구분해서 알아보기 위함

##3. Weatherinfo 테이블
###3-1. 기준 attribute : avg_tmp
###3-2. 이유 : avg_tmp(평균 온도) attribute를 구간을 나누어 지역과 날짜 정보를 추출해보기 위함

##4. Regioninfo 테이블
###4-1. 기준 attribute : province
###4-2. 이유 : province(지역) attribute를 구분하여 선택한 지역의 통계 정보를 알아보기 위함